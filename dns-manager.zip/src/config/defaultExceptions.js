export const defaultExceptions = [
    'r21',
    'r22',
    'email',
    'onmicrosoft.com'
    // aggiungi qui altre eccezioni predefinite
  ];